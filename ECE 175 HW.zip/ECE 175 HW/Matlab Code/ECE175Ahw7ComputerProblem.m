%% Support Vector Machine (Linear Kernel)

clear all;
close all;

load('data.mat');
load('label.mat');

addpath('/windows/');

%% Digit 68 Train data, label, count, reshape

digit68CountTrain = 0;
m = 0;
for i=1:5000
    if labelTrain(i) == 6 || labelTrain(i) == 8
        m = m + 1;
        digit68Train(:,:,m) = imageTrain(:,:,i);
        digit68LabelTrain(m,1) = labelTrain(i,1);
        digit68CountTrain = digit68CountTrain + 1;
    end
end

digit68ReshapeTrain = zeros(digit68CountTrain,784);
for i=1:digit68CountTrain
    digit68ReshapeTrain(i,:) = reshape(digit68Train(:,:,i),1,784); %rows are digit68Train vectors
end

%% Digit 68 Test data, label, count, reshape

digit68CountTest = 0;
m = 0;
for i=1:500
    if labelTest(i) == 6 || labelTest(i) == 8
        m = m + 1;
        digit68Test(:,:,m) = imageTest(:,:,i);
        digit68LabelTest(m,1) = labelTest(i,1);
        digit68CountTest = digit68CountTest + 1;
    end
end

digit68ReshapeTest = zeros(digit68CountTest,784);
for i=1:digit68CountTest
    digit68ReshapeTest(i,:) = reshape(digit68Test(:,:,i),1,784); %rows are digit68Test vectors
end

%% Train SVM Model

% svm options
svmOptions = ['-t 0 -c 2^-4'];

% train SVM
model = svmtrain(digit68LabelTrain,digit68ReshapeTrain,svmOptions);

% test SVM on test data
[predictedLabelTest,accuracyTest,decisionValuesTest] = svmpredict(digit68LabelTest,digit68ReshapeTest,model);

%% Plot 5 Support Vectors (class 6) +

% %pick 5 random sv_indices from model
% figure(1);
% subplot(1,5,1);
% imshow(digit68Train(:,:,3),[]);
% subplot(1,5,2);
% imshow(digit68Train(:,:,44),[]);
% subplot(1,5,3);
% imshow(digit68Train(:,:,81),[]);
% subplot(1,5,4);
% imshow(digit68Train(:,:,82),[]);
% subplot(1,5,5);
% imshow(digit68Train(:,:,94),[]);

%% Plot 5 Support Vectors (class 8) -

% %pick 5 random sv_indices from model
% figure(2);
% subplot(1,5,1);
% imshow(digit68Train(:,:,756),[]);
% subplot(1,5,2);
% imshow(digit68Train(:,:,769),[]);
% subplot(1,5,3);
% imshow(digit68Train(:,:,781),[]);
% subplot(1,5,4);
% imshow(digit68Train(:,:,789),[]);
% subplot(1,5,5);
% imshow(digit68Train(:,:,806),[]);

%% Find vector normal to hyperplane

%normal = sum(a*y*x);
normal = zeros(1,784);
for i=1:88
    modelIndex = model.sv_indices(i);
    normal(1,:) = normal(1,:) + (model.sv_coef(i) * digit68ReshapeTrain(modelIndex,:));
end

% Reshape
normalReshape = zeros(28,28);
for i=1:88
    normalReshape(:,:) = reshape(normal(1,:),28,28);
end

%Plot
figure(3);
imshow(normalReshape,[]);

%% Absolute value distance from each digit68Test to classification boundary

%w^t + b

distance = zeros(digit68CountTest,1);
% b = -(normal * (digit68ReshapeTrain(3,:)' - digit68ReshapeTrain(756,:)')) / 2;
b = -model.rho;

for i=1:digit68CountTest
    distance(i) = abs(normal * digit68ReshapeTest(i,:)' + b) / norm(normal);
end

%% Plot histogram distances using 10 bins

figure(4);
hist(distance, 10)

%% Five digit68Test farthest from boundary, reshape, plot (class 6)

%distances from digit6 to boundary
digit6CountTest = 0;
m=0;
for i=1:83
    if digit68LabelTest(i) == 6
        m = m + 1;
        distance6(m) = distance(i);
        digit6CountTest = digit6CountTest + 1;
    end;
end

distance6Order = sort(distance6,'descend');
distance6Thresh5 = distance6Order(1:5);

farthestTest6 = zeros(5,784); %rows are farthestTest6 vectors
for i=1:5
    for j=1:digit68CountTest
        if distance6Thresh5(i) == distance(j)
            farthestTest6(i,:) = digit68ReshapeTest(j,:);
        end
    end
end

%reshape
farthestTest6Reshape = zeros(28,28,5);
for i=1:5
    farthestTest6Reshape(:,:,i) = reshape(farthestTest6(i,:),28,28);
end

%plot
figure(5);
for i=1:5
    subplot(1,5,i);
    imshow(farthestTest6Reshape(:,:,i),[]);
end

%% Five digit68Test closest from boundary, reshape, plot (class 6)

distance6Order = sort(distance6,'ascend');
distance6Thresh5 = distance6Order(1:5);

closestTest6 = zeros(5,784); %rows are closestTest6 vectors
for i=1:5
    for j=1:digit68CountTest
        if distance6Thresh5(i) == distance(j)
            closestTest6(i,:) = digit68ReshapeTest(j,:);
        end
    end
end

%reshape
closestTest6Reshape = zeros(28,28,5);
for i=1:5
    closestTest6Reshape(:,:,i) = reshape(closestTest6(i,:),28,28);
end

%plot
figure(6);
for i=1:5
    subplot(1,5,i);
    imshow(closestTest6Reshape(:,:,i),[]);
end

%% Five digit68Test farthest from boundary, reshape, plot (class 8)

%distances from digit8 to boundary
digit8CountTest = 0;
m=0;
for i=1:83
    if digit68LabelTest(i) == 8
        m = m + 1;
        distance8(m) = distance(i);
        digit8CountTest = digit8CountTest + 1;
    end;
end

distance8Order = sort(distance8,'descend');
distance8Thresh5 = distance8Order(1:5);

farthestTest8 = zeros(5,784); %rows are farthestTest6 vectors
for i=1:5
    for j=1:digit68CountTest
        if distance8Thresh5(i) == distance(j)
            farthestTest8(i,:) = digit68ReshapeTest(j,:);
        end
    end
end

%reshape
farthestTest8Reshape = zeros(28,28,5);
for i=1:5
    farthestTest8Reshape(:,:,i) = reshape(farthestTest8(i,:),28,28);
end

%plot
figure(7);
for i=1:5
    subplot(1,5,i);
    imshow(farthestTest8Reshape(:,:,i),[]);
end

%% Five digit68Test closest from boundary, reshape, plot (class 8)

distance8Order = sort(distance8,'ascend');
distance8Thresh5 = distance8Order(1:5);

closestTest8 = zeros(5,784); %rows are closestTest8 vectors
for i=1:5
    for j=1:digit68CountTest
        if distance8Thresh5(i) == distance(j)
            closestTest8(i,:) = digit68ReshapeTest(j,:);
        end
    end
end

%reshape
closestTest8Reshape = zeros(28,28,5);
for i=1:5
    closestTest8Reshape(:,:,i) = reshape(closestTest8(i,:),28,28);
end

%plot
figure(8);
for i=1:5
    subplot(1,5,i);
    imshow(closestTest8Reshape(:,:,i),[]);
end

%%
%% Support Vector Machine (Gaussian Kernel)

clear all;
close all;

load('data.mat');
load('label.mat');

addpath('/windows/');

%% Normalize image values

imageTrain = imageTrain/255;
imageTest = imageTest/255;

%% imageTrainReshape

imageTrainReshape = zeros(5000,784);
for i=1:5000
    imageTrainReshape(i,:) = reshape(imageTrain(:,:,i),1,784); %rows are imageTrain vectors
end

%% imageTestReshape

imageTestReshape = zeros(500,784);
for i=1:500
    imageTestReshape(i,:) = reshape(imageTest(:,:,i),1,784); %rows are imageTest vectors
end

%% 2-fold Cross Validation to find most accurate C and gamma

% C = [2^-3; 2^-1; 2^1; 2^3; 2^5; 2^7; 2^9; 2^11]; %i
% gamma = [2^-11; 2^-9; 2^-7; 2^-5; 2^-3; 2^-1]; %j
% accuracy = zeros(8,6);
% 
% for i=1:8
%     for j=1:6
%         x = C(i,1);
%         y = gamma(j,1);
%         svmOptions = ['-t 2 -c ', num2str(x), ' -g ', num2str(y), ' -v 2'];
%         accuracy(i,j) = svmtrain(labelTrain,imageTrainReshape,svmOptions);
%     end
% end

%% Support Vector Machine Gaussian

clear all;
close all;

load('data.mat');
load('label.mat');

addpath('/windows/');

%% Normalize image values

imageTrain = imageTrain/255;
imageTest = imageTest/255;

%% imageTrainReshape

imageTrainReshape = zeros(5000,784);
for i=1:5000
    imageTrainReshape(i,:) = reshape(imageTrain(:,:,i),1,784); %rows are imageTrain vectors
end

%% imageTestReshape

imageTestReshape = zeros(500,784);
for i=1:500
    imageTestReshape(i,:) = reshape(imageTest(:,:,i),1,784); %rows are imageTest vectors
end

%% 2-fold Cross Validation to find most accurate C and gamma

% C = [2^-3; 2^-1; 2^1; 2^3; 2^5; 2^7; 2^9; 2^11]; %i
% gamma = [2^-11; 2^-9; 2^-7; 2^-5; 2^-3; 2^-1]; %j
% accuracy = zeros(8,6);
% 
% for i=1:8
%     for j=1:6
%         x = C(i,1);
%         y = gamma(j,1);
%         svmOptions = ['-t 2 -c ', num2str(x), ' -g ', num2str(y), ' -v 2'];
%         accuracy(i,j) = svmtrain(labelTrain,imageTrainReshape,svmOptions);
%     end
% end

%% Train SVM Model

% svm options
svmOptions = ['-t 2 -c 32 -g 0.03125'];  %2^5, 2^-5

% train SVM
model = svmtrain(labelTrain,imageTrainReshape,svmOptions);

% test SVM on test data
[predictedLabelTest,accuracyTest,decisionValuesTest] = svmpredict(labelTest,imageTestReshape,model);






