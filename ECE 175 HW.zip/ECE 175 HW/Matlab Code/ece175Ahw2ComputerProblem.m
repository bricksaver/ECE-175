%HW 2 Computer Problem - Using 5000 trained data sets to test how accurate
%500 NEW test data sets can be correctly identified. Data sets consist of
%28x28 pixels forming digits 0 to 9.
%takes 24 sec to run

%counting training labels for each class
classes = [0,1,2,3,4,5,6,7,8,9];
countTrain = zeros(1,10);
for i = 0:9
    for j = 1:5000
        if labelTrain(j) == i
            countTrain(i+1) = countTrain(i+1)+1; %classes 0 to 9 correspond to indexes 1 to 10 respectively
        end
    end
end

%1.
%Use of training images and ground truth info to train nearest neighbor
%classifier using Euclidian distance metric

%test database
probError = zeros(1,10);
numCorrect = zeros(1,10);
numError = zeros(1,10);
misclassifiedTest = zeros(1,5); %store the indexes of first 5 misclassified test images
misclassifiedTrain = zeros(1,5); %store the indexes of corresponding 5 closest misclassified train images
errorCount = 0;
for i = 1:500
    distTrain = zeros(1,10);
    minDist = Inf;
    winnerLabel = 0;
    for j = 1:5000
        %dist = d(imageTest,imageTrain);
        dist = 0;
        for m = 1:28
          for n = 1:28
             dist = dist + (imageTest(m,n,i) - imageTrain(m,n,j))^2; %classes 0 to 9 correspond to indexes 1 to 10 respectively
          end
        end
        dist = sqrt(dist);
        %distTrain(labelTrain(j)+1) = distTrain(labelTrain(j)+1) + dist;  %accumulated distance over 10 classes
        if dist < minDist
            minDist = dist;
            winnerLabel = labelTrain(j);
            winnerIndex = j;
        end
    end
    
    if winnerLabel == labelTest(i)
        numCorrect(winnerLabel+1) = numCorrect(winnerLabel+1) + 1;
    else
        numError(winnerLabel+1) = numError(winnerLabel+1) + 1;
        errorCount = errorCount + 1;
        if errorCount <= 5
            misclassifiedTest(errorCount) = i; %stores indexes of first 5 misclassifications of test images
            misclassifiedTrain(errorCount) = winnerIndex; %store indexes of corresponding train images
            figure(2*errorCount-1);
            imshow(imageTest(:,:,i))            %misclassified test image
            title('misclassified test image');
            figure(2*errorCount);
            imshow(imageTrain(:,:,winnerIndex)) %closest training image
            title('closest training image');
        end
    end
end
for i = 1:10
    probError(i) = numError(i)/(numCorrect(i)+numError(i)); %P(error|class=i)
end

%plot error rates
x = 0:9
figure(11);
plot(x,probError)

%2.
probTotalError = 0;
for i = 1:10
    probTotalError = probTotalError + (numCorrect(i)+numError(i))/500 * probError(i); %Baye's Rule
end
    
%3.
%located in part 2
%

    
    
    
    
    
    
    
    