%1.
%{
% K-Means w/ 10 random images as class mean initializations
% initialize 10 random images as class means
numClusters = 10;
classMeans = zeros(28,28,numClusters);
for i = 1:numClusters
    classMeans(:,:,i) = imageTrain(:,:,i+100);
end

% run k-means
changesPercent = Inf;
totalPoints = 5000;
pointPseudoLabels = zeros(totalPoints);
algorithmIterations = 0;
currentMinDistClass = zeros(totalPoints); %pseudo-label for points
currentMinDist = zeros(totalPoints);

while changesPercent>=0.2
    sumClassPoints = zeros(28,28,numClusters);
    numClassPoints = zeros(numClusters);
    changes = 0;
    for n = 1:totalPoints
        currentMinDist(n) = Inf;
        changeOccurred = 0;
        for j = 1:numClusters
            euclideanDist = (norm(imageTrain(:,:,n) - classMeans(:,:,j)))^2;
            if euclideanDist < currentMinDist(n)
                currentMinDist(n) = euclideanDist;
                newMinDistClass = j;
                if newMinDistClass ~= currentMinDistClass(n)
                    currentMinDistClass(n) = newMinDistClass;
                    changeOccurred = 1;
                end
            end
        end
        if changeOccurred == 1
            changes = changes + 1;
        end
        for a = 1:28
            for b = 1:28
                sumClassPoints(a,b,currentMinDistClass(n)) = sumClassPoints(a,b,currentMinDistClass(n)) + imageTrain(a,b,n);   
            end
        end
        numClassPoints(currentMinDistClass(n)) = numClassPoints(currentMinDistClass(n)) + 1;      
    end
    for i = 1:numClusters
        for a = 1:28
            for b = 1:28
                classMeans(:,:,i) = ((1/numClassPoints(i))*sumClassPoints(:,:,i));
            end
        end
    end
    changesPercent = (changes/totalPoints)*100;
    algorithmIterations = algorithmIterations + 1
end
for i = 1:10
    subplot(2,5,i);
    imshow(mat2gray(classMeans(:,:,i), [0 255]))
end
%}
%2.
% K-means with 10 data images as class mean initializations

% initialize 10 images from data as class means
numClusters = 10;
classMeans = zeros(28,28,numClusters);
for i = 1:numClusters
   classMeans(:,:,i) = imageTrain(:,:,i+3000); 
end

% run k-means
changesPercent = Inf;
totalPoints = 5000;
pointPseudoLabels = zeros(totalPoints);
algorithmIterations = 0;
currentMinDistClass = zeros(totalPoints); %pseudo-label for points
currentMinDist = zeros(totalPoints);

while changesPercent>=0.2
    sumClassPoints = zeros(28,28,numClusters);
    numClassPoints = zeros(numClusters);
    changes = 0;
    for n = 1:totalPoints
        currentMinDist(n) = Inf;
        changeOccurred = 0;
        for j = 1:numClusters
            euclideanDist = (norm(imageTrain(:,:,n) - classMeans(:,:,j)))^2;
            if euclideanDist < currentMinDist(n)
                currentMinDist(n) = euclideanDist;
                newMinDistClass = j;
                if newMinDistClass ~= currentMinDistClass(n)
                    currentMinDistClass(n) = newMinDistClass;
                    changeOccurred = 1;
                end
            end
        end
        if changeOccurred == 1
            changes = changes + 1;
        end
        for a = 1:28
            for b = 1:28
                sumClassPoints(a,b,currentMinDistClass(n)) = sumClassPoints(a,b,currentMinDistClass(n)) + imageTrain(a,b,n);   
            end
        end
        numClassPoints(currentMinDistClass(n)) = numClassPoints(currentMinDistClass(n)) + 1;      
    end
    for i = 1:numClusters
        for a = 1:28
            for b = 1:28
                classMeans(:,:,i) = ((1/numClassPoints(i))*sumClassPoints(:,:,i));
            end
        end
    end
    changesPercent = (changes/totalPoints)*100;
    algorithmIterations = algorithmIterations + 1
end
for i = 1:10
    subplot(2,5,i);
    imshow(mat2gray(classMeans(:,:,i), [0 255]))
end
imageMeanLabel = [5,0,9,1,6,2,8,3,7]
%}
    
    
    
