%a
mu = 0;
sd = 1;
x = sd*randn(500,1)+mu;
y = 1/(2*pi*sd)*exp(-(x-mu).^2/(2*sd^2));
scatter(x,y);
d = mahal(x,y);
plot(d)
%contour(d) %im not sure what i'm doing here. learn mahalanobis distance
           %before proceeding further

%b


%c
