%HW5 Classification - Copied from HW3

imageMeanLabel = [5,0,9,1,6,2,8,3,7] %note: no mean for class 4.

%Classification by BDR
classMeansReshaped = reshape(classMeans,[784,10]);
classMeansReshaped = classMeansReshaped(1:784,1:9); %discard 2nd 9 mean located at end of means.

testClassification = zeros(500,1); %contains classified labels
for i = 1:500
    classProb = zeros(9,1);
    currentClassProb = zeros(9,1);
    for j = 1:9
        %note inverse of identity covariance is 1
        %can ignore right-hand side of equation since it is constant
        %right hand side looks as follows:
        %constants = -0.5*log(2*pi)^28^2 + log(1/10);
        classProb(j) = -0.5*(reshape(imageTest(:,:,i),784,1)-classMeansReshaped(:,j))'*(reshape(imageTest(:,:,i),784,1)-classMeansReshaped(:,j));
        if classProb(j) > classProb(j)
            currentClassProb(j) = classProb(j)
        end
    end
    [Y,I] = max(classProb); %Y = value, I = index
    testClassification(i) = imageMeanLabel(I);
end      
%find error
countTrain = zeros(1,10);
numError = zeros(1,10);
for i = 1:10
    for j = 1:500
        if labelTest(j) == i-1
            countTrain(i) = countTrain(i) + 1;
            if testClassification(j) ~= labelTest(j)
                numError(i) = numError(i) + 1;
            end
        end
    end
end
probErrorClass = zeros(1,10);
for i = 1:10
    probErrorClass(i) = numError(i)/countTrain(i);
end      
probErrorClass(5) = 0.5 %since no mean for class 4, set its error rate to 50%
%plot error per class
figure;
x = 0:9;
bar(x,probErrorClass)
%calculate total error probability
totalNumError = 0;
for i = 1:10
    totalNumError = totalNumError + numError(i);
end
totalProbError = totalNumError/500
%}