%ECE 175A HW7
%1.a)
%count sixes and eights in training data
numTrainSix = 0;
numTrainEight = 0;
for i = 1:5000
    if labelTrain(i) == 6
        numTrainSix = numTrainSix + 1;
    end
    if labelTrain(i) == 8
        numTrainEight = numTrainEight + 1;
    end
end
numTrainSixEight = numTrainSix + numTrainEight;

%get imageTrainSixEight & labelTrainSixEight
imageTrainSixEight = zeros(28,28,numTrainSixEight);
labelTrainSixEight = zeros(numTrainSixEight,1);
k=1;
for i=1:5000
    if labelTrain(i) == 6 | imageTrain(i) == 8
        for a = 1:28
            for b = 1:28
                imageTrainSixEight(a,b,k) = imageTrain(a,b,i);
            end
        end
        labelTrainSixEight(k) = labelTrain(i);
        k = k + 1;
    end
end

%get training instance matrix imageTrainingInstanceSixEight
imageTrainingInstanceSixEight = reshape(imageTrainSixEight,[numTrainSixEight,784]);

%count sixes and eights in test data
numTestSix = 0;
numTestEight = 0;
for i = 1:500
    if labelTestNew(i) == 6
        numTestSix = numTestSix + 1;
    end
    if labelTestNew(i) == 8
        numTestEight = numTestEight + 1;
    end
end
numTestSixEight = numTestSix + numTestEight;

%get imageTrainSixEight & labelTrainSixEight
imageTestSixEight = zeros(28,28,numTestSixEight);
labelTestSixEight = zeros(numTestSixEight,1);
k=1;
for i=1:500
    if labelTestNew(i) == 6 | imageTestNew(i) == 8
        for a = 1:28
            for b = 1:28
                imageTestSixEight(a,b,k) = imageTestNew(a,b,i);
            end
        end
        labelTestSixEight(k) = labelTestNew(i);
        k = k + 1;
    end
end

%get test instance matrix imageTestingInstanceSixEight
imageTestingInstanceSixEight = reshape(imageTestSixEight,[numTestSixEight,784]);

%Train SVM model with training images from classes digit6 and digit8
model = svmtrain(labelTrainSixEight, imageTrainingInstanceSixEight, ['t 0 -c 2^-4']);

%GETTING ERROR SO COMMENTING OUT BELOW FOR NOW
%{
%Perform classification on test data from classes digit6 and digit 8 using svm model
[predicted_label, accuracy, decision_values] = svmpredict(labelTestSixEight, imageTestingInstanceSixEight, model);

%classification accuracy
sumAccuracy = 0;
lengthAccuracy = length(accuracy);
for i=1:lengthAccuracy
    sumAccuracy = sumAccuracy + accuracy(i)
end
totalClassificationAccuracy = sumAccuracy/lengthAccuracy;

%1.b)
%get 5 support vectors closest to classification boundaries as 28x28 images
svmSVIndeces = model.sv_indeces;
numIndeces = length(svmSVIndeces);
fiveSVMdigit6SVs = zeros(28,28,5);
fiveSVMdigit8SVs = zeros(28,28,5);
countDigit6SV = 1;
countDigit8SV = 1;
for i=1:numIndeces
    if countDigit6SV<5 
        if labelTestSixEight(i) == 6
            fiveSVMdigit6SVs(:,:,countDigit6SV) = reshape(imageTestSixEight(i,:),[28,28]);
            countDigit6SV = countDigit6SV + 1;
        end
    end
    if countDigit8SV<5
        if labelTestSixEight(i) == 8
            fiveSVMdigit8SVs(:,:,countDigit8SV) = reshape(imageTestSixEight(i,:),[28,28]);
            countDigit8SV = countDigit8SV + 1;
        end
    end
end
figure;
for i = 1:5
    subplot(2,5,i);
    imshow(fiveSVMdigit6SVs);
    title = ('Digit6 support vector');
end
for i = 6:10
    subplot(2,5,i);
    imshow(fiveSVMdigit8SVs);
    title = ('Digit8 support vector);
end
    
%1.c)
%get normal vector separating hyperplane as 28x28 image
svmSVCoefficients = model.sv_coef
n = sum(svmSVCoefficients*y*x);
figure;
imshow(n)
title = ('normal vector separating hyperplane');

%1.d)
%compute absolute distance of each test image to boundary
%%%%BEST WAY TO FIND DISTANCE FROM IMAGE TO BOUNDARY? HELP PLZ.
absDistTestImages = zeros(numTestSixEight,10);
magSVCoeff = abs(svmSVCoefficients)
for i=1:numTestSixEight
    j = labelTestSixEight(i)
    absDistTestImages(i,j) = dot(svmSVCoefficients(i,:),reshape(testImageSixEight,[784,1]))/magSVCoeff;
end
%plot histogram for all distances using 10 bins

1.e)
%plot 5 test images from each class furthest from boundary
%%%%NEED PART D

1.f)
plot 5 test images from each class closest to boundary
%%%%NEED PART D

%}



    














