% Principal Component Analysis
%% Mean

sum = zeros(28,28);

for i=1:5000
    sum = sum + imageTrain(:,:,i);
end
mean = sum/5000;
meanReshape = reshape(mean(:,:),784,1);

%% Covariance and imageTrainReshape

sum = 0;
imageTrainReshape = zeros(784, 5000);

for i=1:5000
    imageTrainReshape(:,i) = reshape(imageTrain(:,:,i),784,1);
    X = imageTrainReshape(:,i) - meanReshape;
    X2 = X*X';
    sum = sum + X2;
end
   
covariance = sum/5000;

%% Eigenvalues and Eigenvectors of covariance

eigenvalue = eig(covariance);
[eigenvector,~] = eig(covariance); %columns are eigenvectors

eigenvalueOrder = sort(eigenvalue,'descend');

%% Threshold top 10 eigenvalues and eigenvectors and Plot

eigenvalueThresh10 = eigenvalueOrder(1:10);

eigenvectorThresh10 = zeros(784,10); %find eigenvectorThresh
for i=1:10
    for j=1:784
        if eigenvalueThresh10(i) == eigenvalue(j)
            eigenvectorThresh10(:,i) = eigenvector(:,j); %columns are eigenvectors
        end
    end
end

figure(1); %plot eigenvectors of 10 largest eigenvalues
for i=1:10
    eigenvectorImage = reshape(eigenvectorThresh10(:,i),28,28);
    subplot(2,5,i);
    imshow(eigenvectorImage,[]);
end

figure(2); %plot all eigenvalues in descending order
plot(eigenvalueOrder);

%% Find imageTestReshape

imageTestReshape = zeros(784,500);

for i=1:500
    imageTestReshape(:,i) = reshape(imageTest(:,:,i),784,1); %columns are imageTest vectors
end

%% Threshold top k eigenvalues and eigenvectors
    
k = 60; %%%%%%% DIMENSION [5,10,20,30,40,60,90,130,180,250,350]

clear collect;

%find top eigenvectors of k
eigenvalueThreshk = eigenvalueOrder(1:k);

eigenvectorThreshk = zeros(784,k); %find eigenvectorThreshk
for i=1:k
    for j=1:784
        if eigenvalueThreshk(i) == eigenvalue(j)
            eigenvectorThreshk(:,i) = eigenvector(:,j); %columns are eigenvectors (A)
        end
    end
end

%% Project onto eigenvalue space yi=A*ti'

projectionTest = eigenvectorThreshk' * (imageTestReshape - meanReshape)./255; %5x500
projectionTrain = eigenvectorThreshk' * (imageTrainReshape - meanReshape)./255; %5x5000

%% Calculate class means from imageTrain

meanClass = zeros(k,10);
for i=1:10
    sum = zeros(k,1);
    count = 0;
    for j=1:5000
       if labelTrain(j) == (i-1)
            sum = sum + projectionTrain(:,j);
            count = count + 1;
       end
    end
    meanClass(:,i) = sum ./ count;
end

figure;
for i=1:5
    subplot(k/3,k,i)
    imshow(meanClass(:,i),[]);
end

%% Calculate class covariances from imageTrain

covarianceClass = zeros(k,k,10);
m=0;
for i=1:10
    m=0;
    for j = 1:5000
        if labelTrain(j) == i-1
            m = m + 1;
            collect(m,:) = projectionTrain(:,j)';
        end
    end
    covarianceClass(:,:,i) = cov(collect(:,:));
end

% figure;
% for i=1:10
%     subplot(k/3,k,i)
%     imshow(covarianceClass(:,:,i),[])
% end

%% Baye's Decision Rule - gives pdf of each class

optimalClass = zeros(500,1);

for i = 1:500
    pdf = zeros(10,1);
    for j = 1:10            
       % pdf(j) = -0.5*(projectionTest(:,i)-meanClass(:,j))'*pinv(covarianceClass(:,:,j))*(projectionTest(:,i)-meanClass(:,j))- 0.5*k*log(2*pi) - 0.5*log(det(covarianceClass(:,:,j))) + log(1/10);
       pdf(j) = mvnpdf(projectionTest(:,i)',meanClass(:,j)',covarianceClass(:,:,j));
    end
    
    [row,col] = max(pdf);
    optimalClass(i) = col-1;
end

%% Calculate Total Error of k

totalError = 0;

for i = 1:10
    for j = 1:500
        if labelTest(j) == i-1
            if optimalClass(j) ~= labelTest(j)
                totalError = totalError + 1;
            end         
        end
    end
end

totalError = totalError/500;

%% Plot Total Error (after finding totaError of each dimension, plot separately on Command Window)

%manually input totalError of each dimension
totalErrorClass = [0.348,0.154,0.074,0.060,0.058,0.058,0.070,0.104,0.114,0.130];

figure(3);
bar([5,10,20,30,40,60,90,130,180,250], totalErrorClass)
xlabel('Dimension')
ylabel('Total Error')






















